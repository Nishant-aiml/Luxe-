import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { validateAuth, isRetailerRoute, isCustomerRoute, getRedirectUrl } from '@/lib/auth'

const PUBLIC_PATHS = new Set([
  '/',
  '/favicon.ico',
  '/manifest.json',
  '/robots.txt',
  '/sitemap.xml',
])

const STATIC_PATH_PREFIXES = [
  '/_next',
  '/images',
  '/icons',
  '/fonts',
]

export async function middleware(request: NextRequest) {
  // Create response with security headers
  const response = NextResponse.next()
  
  // Add security headers
  const headers = response.headers
  headers.set('X-DNS-Prefetch-Control', 'on')
  headers.set('Strict-Transport-Security', 'max-age=63072000; includeSubDomains; preload')
  headers.set('X-Frame-Options', 'SAMEORIGIN')
  headers.set('X-Content-Type-Options', 'nosniff')
  headers.set('Referrer-Policy', 'strict-origin-when-cross-origin')
  headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()')
  headers.set('X-XSS-Protection', '1; mode=block')

  // Allow public and static paths
  const { pathname } = request.nextUrl
  
  // Check if path is public
  if (PUBLIC_PATHS.has(pathname)) {
    return response
  }

  // Check if path starts with any static prefix
  if (STATIC_PATH_PREFIXES.some(prefix => pathname.startsWith(prefix))) {
    return response
  }

  // Handle API routes separately
  if (pathname.startsWith('/api/')) {
    return response
  }

  const user = await validateAuth(request)

  // Handle authenticated users
  if (user) {
    // Prevent retailers from accessing customer routes and vice versa
    if (user.role === 'retailer' && isCustomerRoute(pathname)) {
      return NextResponse.redirect(new URL('/dashboard', request.url))
    }
    if (user.role === 'customer' && isRetailerRoute(pathname)) {
      return NextResponse.redirect(new URL('/shop', request.url))
    }

    // Redirect from auth pages to appropriate dashboard
    if (pathname === '/login' || pathname === '/register' || 
        pathname === '/retailer/login' || pathname === '/retailer/register') {
      return NextResponse.redirect(new URL(getRedirectUrl(user.role), request.url))
    }

    return response
  }

  // Handle unauthenticated users
  if (isRetailerRoute(pathname)) {
    return NextResponse.redirect(new URL('/retailer/login', request.url))
  }

  if (isCustomerRoute(pathname) && pathname !== '/login' && pathname !== '/register') {
    return NextResponse.redirect(new URL('/login', request.url))
  }

  return response
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico).*)',
  ],
}
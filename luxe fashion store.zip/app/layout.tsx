import './globals.css'
import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import { Toaster } from "@/components/ui/toaster"
import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({ 
  subsets: ['latin'],
  display: 'swap',
  preload: true,
  adjustFontFallback: true,
  variable: '--font-inter',
})

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: 'white' },
    { media: '(prefers-color-scheme: dark)', color: 'black' },
  ],
}

export const metadata: Metadata = {
  metadataBase: new URL('https://luxe-fashion.com'),
  title: {
    default: 'LUXE - Fashion E-commerce Platform',
    template: '%s | LUXE Fashion'
  },
  description: 'Next-generation fashion e-commerce platform with AI-powered recommendations',
  keywords: ['fashion', 'e-commerce', 'AI', 'shopping', 'luxury'],
  authors: [{ name: 'LUXE Fashion' }],
  manifest: '/manifest.json',
  robots: {
    index: true,
    follow: true,
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://luxe-fashion.com',
    title: 'LUXE Fashion',
    description: 'Next-generation fashion e-commerce platform',
    siteName: 'LUXE Fashion',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'LUXE Fashion',
    description: 'Next-generation fashion e-commerce platform',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning className={inter.variable}>
      <head>
        <link rel="preconnect" href="https://images.unsplash.com" />
      </head>
      <body className={inter.className}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  )
}
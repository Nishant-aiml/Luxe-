"use client"

import { Smartphone } from "lucide-react"
import { Button } from "@/components/ui/button"

export function SecuritySettings() {
  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <h3 className="font-medium">Two-Factor Authentication</h3>
        <div className="flex items-center space-x-4">
          <Smartphone className="h-5 w-5 text-muted-foreground" />
          <div className="flex-1">
            <p className="font-medium leading-none mb-1">
              Authenticator App
            </p>
            <p className="text-sm text-muted-foreground">
              Use an authenticator app to generate verification codes
            </p>
          </div>
          <Button variant="outline">Setup</Button>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-medium">Password</h3>
        <Button variant="outline">Change Password</Button>
      </div>

      <div className="space-y-4">
        <h3 className="font-medium">Login Sessions</h3>
        <Button variant="outline" className="text-red-600">
          Sign Out All Devices
        </Button>
      </div>
    </div>
  )
}
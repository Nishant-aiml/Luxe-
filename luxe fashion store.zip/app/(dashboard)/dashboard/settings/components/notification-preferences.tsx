"use client"

import { useState } from "react"
import { Bell, Mail, Shield, Store } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"

const notificationSettings = [
  {
    title: "Order Updates",
    description: "Receive notifications about new orders and updates",
    icon: Bell,
  },
  {
    title: "Inventory Alerts",
    description: "Get notified when products are low in stock",
    icon: Store,
  },
  {
    title: "Customer Messages",
    description: "Receive messages from customers",
    icon: Mail,
  },
  {
    title: "Security Alerts",
    description: "Get notified about security events",
    icon: Shield,
  },
]

export function NotificationPreferences() {
  const [notificationPrefs, setNotificationPrefs] = useState({
    orderUpdates: true,
    inventoryAlerts: true,
    customerMessages: true,
    securityAlerts: true,
  })

  return (
    <div className="space-y-6">
      {notificationSettings.map((setting, index) => (
        <div
          key={index}
          className="flex items-center justify-between space-x-4"
        >
          <div className="flex items-center space-x-4">
            <setting.icon className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="font-medium leading-none mb-1">
                {setting.title}
              </p>
              <p className="text-sm text-muted-foreground">
                {setting.description}
              </p>
            </div>
          </div>
          <Switch
            checked={notificationPrefs[setting.title.toLowerCase().replace(" ", "") as keyof typeof notificationPrefs]}
            onCheckedChange={(checked) =>
              setNotificationPrefs(prev => ({
                ...prev,
                [setting.title.toLowerCase().replace(" ", "")]: checked,
              }))
            }
          />
        </div>
      ))}

      <div className="pt-4">
        <Button>Save Preferences</Button>
      </div>
    </div>
  )
}
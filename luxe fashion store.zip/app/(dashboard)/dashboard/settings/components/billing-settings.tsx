"use client"

import { CreditCard } from "lucide-react"
import { Button } from "@/components/ui/button"

export function BillingSettings() {
  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <h3 className="font-medium">Current Plan</h3>
        <div className="p-4 border rounded-lg">
          <div className="flex justify-between items-center mb-4">
            <div>
              <p className="font-medium">Professional Plan</p>
              <p className="text-sm text-muted-foreground">
                $49.99/month
              </p>
            </div>
            <Button>Upgrade Plan</Button>
          </div>
          <div className="space-y-2">
            <p className="text-sm">Features included:</p>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Unlimited products</li>
              <li>• Advanced analytics</li>
              <li>• Priority support</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-medium">Payment Method</h3>
        <div className="flex items-center space-x-4">
          <CreditCard className="h-5 w-5 text-muted-foreground" />
          <div className="flex-1">
            <p className="font-medium leading-none mb-1">
              •••• •••• •••• 4242
            </p>
            <p className="text-sm text-muted-foreground">
              Expires 12/24
            </p>
          </div>
          <Button variant="outline">Update</Button>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-medium">Billing History</h3>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>March 2024</span>
            <span>$49.99</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>February 2024</span>
            <span>$49.99</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>January 2024</span>
            <span>$49.99</span>
          </div>
        </div>
      </div>
    </div>
  )
}
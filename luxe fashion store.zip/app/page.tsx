import Link from "next/link"
import { ShoppingBag } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-16">
        <div className="flex flex-col items-center justify-center text-center">
          <div className="flex items-center mb-8">
            <ShoppingBag className="h-12 w-12 text-primary mr-3" />
            <h1 className="text-5xl font-bold">LUXE</h1>
          </div>
          
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Choose Your Experience
          </h2>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl w-full mt-8">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">For Shoppers</h3>
              <p className="text-muted-foreground mb-6">
                Discover AI-powered personalized shopping with virtual try-ons and
                style recommendations.
              </p>
              <Button asChild size="lg" className="w-full">
                <Link href="/shop">Shop Now</Link>
              </Button>
              <div className="mt-4">
                <Link href="/login" className="text-sm text-primary hover:underline">
                  Already have an account? Sign in
                </Link>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">For Retailers</h3>
              <p className="text-muted-foreground mb-6">
                Access powerful AI analytics, inventory management, and real-time
                insights for your business.
              </p>
              <Button asChild size="lg" variant="outline" className="w-full">
                <Link href="/dashboard">Retailer Dashboard</Link>
              </Button>
              <div className="mt-4">
                <Link href="/retailer/login" className="text-sm text-primary hover:underline">
                  Retailer Login
                </Link>
              </div>
            </div>
          </div>

          <div className="mt-16 max-w-2xl">
            <h3 className="text-xl font-semibold mb-4">
              Powered by Advanced AI Technology
            </h3>
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div>
                <h4 className="font-medium mb-2">Smart Recommendations</h4>
                <p className="text-sm text-muted-foreground">
                  Personalized suggestions based on preferences and behavior
                </p>
              </div>
              <div>
                <h4 className="font-medium mb-2">Virtual Try-On</h4>
                <p className="text-sm text-muted-foreground">
                  See how items look before you buy with AR technology
                </p>
              </div>
              <div>
                <h4 className="font-medium mb-2">Real-time Analytics</h4>
                <p className="text-sm text-muted-foreground">
                  Data-driven insights for better business decisions
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
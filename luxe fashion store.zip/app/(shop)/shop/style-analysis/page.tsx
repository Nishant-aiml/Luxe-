"use client"

import { StyleAnalyzer } from "@/components/style/StyleAnalyzer"

export default function StyleAnalysisPage() {
  return (
    <div className="container py-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-4">AI Style Analysis</h1>
          <p className="text-lg text-muted-foreground">
            Get personalized outfit recommendations powered by advanced AI
          </p>
        </div>

        <StyleAnalyzer />
      </div>
    </div>
  )
}
import dynamic from 'next/dynamic'
import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Sparkles, Recycle, Crown, Wand2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

// Dynamically import carousel components
const Carousel = dynamic(() => import('@/components/ui/carousel').then(mod => mod.Carousel))
const CarouselContent = dynamic(() => import('@/components/ui/carousel').then(mod => mod.CarouselContent))
const CarouselItem = dynamic(() => import('@/components/ui/carousel').then(mod => mod.CarouselItem))
const CarouselNext = dynamic(() => import('@/components/ui/carousel').then(mod => mod.CarouselNext))
const CarouselPrevious = dynamic(() => import('@/components/ui/carousel').then(mod => mod.CarouselPrevious))

const featuredProducts = [
  {
    id: 1,
    name: "AI-Curated Wedding Lehenga",
    price: 899.99,
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=500&h=500&fit=crop",
    category: "Traditional",
    sustainability: "Artisan Crafted",
  },
  {
    id: 2,
    name: "Sustainable Denim Collection",
    price: 129.99,
    image: "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=500&h=500&fit=crop",
    category: "Sustainable",
    sustainability: "Recycled Materials",
  },
  {
    id: 3,
    name: "Digital Avatar Outfit",
    price: 49.99,
    image: "https://images.unsplash.com/photo-1558223608-b08a86c12c38?w=500&h=500&fit=crop",
    category: "Digital Fashion",
    sustainability: "Zero Carbon",
  },
]

const collections = [
  {
    title: "AI Personalization",
    description: "Get outfit recommendations tailored to your style and body type",
    image: "https://images.unsplash.com/photo-1445205170230-053b83016050?w=800&h=400&fit=crop",
    href: "/shop/personalized",
    icon: Sparkles,
  },
  {
    title: "Sustainable Fashion",
    description: "Eco-friendly and ethically sourced clothing",
    image: "https://images.unsplash.com/photo-1523381294911-8d3cead13475?w=800&h=400&fit=crop",
    href: "/shop/sustainable",
    icon: Recycle,
  },
  {
    title: "Traditional Wear",
    description: "Custom-fit attire for weddings and festivals",
    image: "https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=800&h=400&fit=crop",
    href: "/shop/traditional",
    icon: Crown,
  },
  {
    title: "Digital Fashion",
    description: "Express yourself in the digital world",
    image: "https://images.unsplash.com/photo-1633536726481-465c3676851d?w=800&h=400&fit=crop",
    href: "/shop/digital",
    icon: Wand2,
  },
]

function ProductCard({ product }: { product: typeof featuredProducts[0] }) {
  return (
    <Link href={`/shop/product/${product.id}`}>
      <Card className="overflow-hidden h-full group">
        <div className="aspect-square relative">
          <div className="absolute top-2 right-2 z-10">
            <span className="px-2 py-1 text-xs font-medium bg-background/95 rounded-full backdrop-blur-sm">
              {product.sustainability}
            </span>
          </div>
          <Image
            src={product.image}
            alt={product.name}
            fill
            className="object-cover transition-transform group-hover:scale-105"
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            priority={true}
          />
        </div>
        <CardContent className="p-4">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">
              {product.category}
            </p>
            <h3 className="font-medium truncate">{product.name}</h3>
            <p className="font-bold">${product.price}</p>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}

function CollectionCard({ collection }: { collection: typeof collections[0] }) {
  const Icon = collection.icon
  return (
    <Link
      href={collection.href}
      className="group relative overflow-hidden rounded-lg"
    >
      <div className="aspect-[2/1] relative">
        <Image
          src={collection.image}
          alt={collection.title}
          fill
          className="object-cover transition-transform group-hover:scale-105"
          sizes="(max-width: 768px) 100vw, 50vw"
          priority={true}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-background/20 p-6 flex flex-col justify-end">
          <div className="flex items-center gap-2 mb-2">
            <Icon className="h-5 w-5" />
            <h3 className="text-xl font-bold">{collection.title}</h3>
          </div>
          <p className="text-muted-foreground">
            {collection.description}
          </p>
        </div>
      </div>
    </Link>
  )
}

export default function ShopPage() {
  return (
    <div className="flex flex-col gap-8 py-8">
      {/* Hero Section */}
      <section className="relative h-[600px] overflow-hidden">
        <Image
          src="https://images.unsplash.com/photo-1589156229687-496a31ad1d1f?w=1600&h=600&fit=crop"
          alt="AI-powered fashion"
          fill
          className="object-cover"
          priority={true}
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/90 to-background/20">
          <div className="container h-full flex items-center">
            <div className="max-w-lg space-y-4">
              <h1 className="text-4xl font-bold">Fashion Reimagined</h1>
              <p className="text-lg text-muted-foreground">
                Experience the future of fashion with AI personalization, virtual try-ons,
                and sustainable choices
              </p>
              <div className="flex gap-4">
                <Button size="lg" asChild>
                  <Link href="/shop/personalized">
                    Try AI Styling
                    <Sparkles className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link href="/shop/virtual-tryon">
                    Virtual Try-On
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Collections Grid */}
      <section className="container">
        <h2 className="text-2xl font-bold mb-6">Explore Collections</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {collections.map((collection) => (
            <CollectionCard key={collection.title} collection={collection} />
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="container">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Featured Products</h2>
          <Button variant="ghost" asChild>
            <Link href="/shop/featured">
              View All
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="container py-12 border-t">
        <div className="grid md:grid-cols-4 gap-8 text-center">
          <div className="space-y-2">
            <Sparkles className="h-8 w-8 mx-auto mb-2" />
            <h3 className="font-medium">AI Personalization</h3>
            <p className="text-sm text-muted-foreground">
              Get style recommendations based on your preferences and body type
            </p>
          </div>
          <div className="space-y-2">
            <Wand2 className="h-8 w-8 mx-auto mb-2" />
            <h3 className="font-medium">Virtual Try-On</h3>
            <p className="text-sm text-muted-foreground">
              Experience clothes virtually before you buy
            </p>
          </div>
          <div className="space-y-2">
            <Recycle className="h-8 w-8 mx-auto mb-2" />
            <h3 className="font-medium">Sustainable Fashion</h3>
            <p className="text-sm text-muted-foreground">
              Shop eco-friendly and ethically sourced clothing
            </p>
          </div>
          <div className="space-y-2">
            <Crown className="h-8 w-8 mx-auto mb-2" />
            <h3 className="font-medium">Traditional Wear</h3>
            <p className="text-sm text-muted-foreground">
              Custom-fit traditional attire for special occasions
            </p>
          </div>
        </div>
      </section>

      {/* Subscription Box Promo */}
      <section className="container">
        <Card className="relative overflow-hidden">
          <div className="md:grid md:grid-cols-2">
            <div className="relative aspect-square md:aspect-auto">
              <Image
                src="https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=800&h=800&fit=crop"
                alt="Sustainable Fashion Box"
                fill
                className="object-cover"
                sizes="(max-width: 768px) 100vw, 50vw"
              />
            </div>
            <div className="p-8 flex flex-col justify-center">
              <h2 className="text-3xl font-bold mb-4">
                Join Our Sustainable Fashion Box
              </h2>
              <p className="text-lg text-muted-foreground mb-6">
                Get curated, eco-conscious fashion delivered to your door monthly.
                Each box includes 3-5 premium sustainable pieces.
              </p>
              <Button size="lg" className="w-fit" asChild>
                <Link href="/shop/subscription">
                  Learn More
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </Card>
      </section>
    </div>
  )
}
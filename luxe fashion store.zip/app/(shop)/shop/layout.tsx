"use client"

import dynamic from 'next/dynamic'
import { useState } from "react"
import Link from "next/link"
import {
  ShoppingBag,
  Search,
  Heart,
  User,
  Menu,
  ShoppingCart,
} from "lucide-react"
import { usePathname } from "next/navigation"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { ThemeProvider } from "@/components/theme-provider"

const NavigationMenu = dynamic(() => import('@/components/ui/navigation-menu').then(mod => mod.NavigationMenu))
const NavigationMenuList = dynamic(() => import('@/components/ui/navigation-menu').then(mod => mod.NavigationMenuList))
const NavigationMenuItem = dynamic(() => import('@/components/ui/navigation-menu').then(mod => mod.NavigationMenuItem))
const NavigationMenuLink = dynamic(() => import('@/components/ui/navigation-menu').then(mod => mod.NavigationMenuLink))

const categories = [
  {
    title: "New Arrivals",
    href: "/shop/new",
  },
  {
    title: "Women",
    href: "/shop/women",
  },
  {
    title: "Men",
    href: "/shop/men",
  },
  {
    title: "Accessories",
    href: "/shop/accessories",
  },
  {
    title: "Sustainable",
    href: "/shop/sustainable",
  },
]

function Header() {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <Link href="/shop" className="mr-6 flex items-center space-x-2">
          <ShoppingBag className="h-6 w-6" />
          <span className="font-bold hidden md:inline-block">LUXE</span>
        </Link>

        <div className="hidden md:flex flex-1">
          <NavigationMenu>
            <NavigationMenuList>
              {categories.map((category) => (
                <NavigationMenuItem key={category.href}>
                  <Link
                    href={category.href}
                    className={cn(
                      "group inline-flex h-10 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50 data-[active]:bg-accent/50 data-[state=open]:bg-accent/50",
                      pathname === category.href && "bg-accent"
                    )}
                  >
                    {category.title}
                  </Link>
                </NavigationMenuItem>
              ))}
            </NavigationMenuList>
          </NavigationMenu>
        </div>

        <div className="flex items-center space-x-4">
          <div className="hidden md:flex relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search products..."
              className="pl-8 w-[200px] lg:w-[300px]"
            />
          </div>

          <nav className="flex items-center space-x-2">
            <Link href="/shop/wishlist">
              <Button variant="ghost" size="icon" className="shrink-0">
                <Heart className="h-5 w-5" />
              </Button>
            </Link>
            <Link href="/shop/cart">
              <Button variant="ghost" size="icon" className="shrink-0">
                <ShoppingCart className="h-5 w-5" />
              </Button>
            </Link>
            <Link href="/shop/account">
              <Button variant="ghost" size="icon" className="shrink-0">
                <User className="h-5 w-5" />
              </Button>
            </Link>
          </nav>

          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden shrink-0"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-80">
              <div className="space-y-4 py-4">
                <div className="px-3 py-2">
                  <h2 className="mb-2 px-4 text-lg font-semibold">Categories</h2>
                  <div className="space-y-1">
                    {categories.map((category) => (
                      <Link
                        key={category.href}
                        href={category.href}
                        onClick={() => setOpen(false)}
                        className={cn(
                          "block px-4 py-2 text-sm rounded-md hover:bg-accent",
                          pathname === category.href && "bg-accent"
                        )}
                      >
                        {category.title}
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}

function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container py-8 md:py-12">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          <div className="space-y-3">
            <h4 className="text-sm font-medium">About</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-foreground">
                  Our Story
                </Link>
              </li>
              <li>
                <Link href="/sustainability" className="text-muted-foreground hover:text-foreground">
                  Sustainability
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-3">
            <h4 className="text-sm font-medium">Customer Service</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-foreground">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/shipping" className="text-muted-foreground hover:text-foreground">
                  Shipping Info
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-3">
            <h4 className="text-sm font-medium">Legal</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/privacy" className="text-muted-foreground hover:text-foreground">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-muted-foreground hover:text-foreground">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-3">
            <h4 className="text-sm font-medium">Newsletter</h4>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                Subscribe for exclusive offers
              </p>
              <div className="flex space-x-2">
                <Input placeholder="Email" className="max-w-[180px]" />
                <Button>Join</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default function ShopLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <ThemeProvider
      attribute="class"
      defaultTheme="system"
      enableSystem
      disableTransitionOnChange
    >
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </div>
    </ThemeProvider>
  )
}
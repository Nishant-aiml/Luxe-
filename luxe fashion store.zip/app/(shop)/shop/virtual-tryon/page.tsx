"use client"

import { useState, useCallback } from "react"
import Image from "next/image"
import { Camera, Upload, RefreshCw, Share2, Sparkles, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"

const products = [
  {
    id: 1,
    name: "Summer Dress",
    image: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=500&h=500&fit=crop",
    price: 89.99,
  },
  {
    id: 2,
    name: "Casual Blazer",
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=500&h=500&fit=crop",
    price: 129.99,
  },
  {
    id: 3,
    name: "Denim Jacket",
    image: "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=500&h=500&fit=crop",
    price: 79.99,
  },
]

export default function VirtualTryOnPage() {
  const [selectedProduct, setSelectedProduct] = useState(products[0])
  const [isProcessing, setIsProcessing] = useState(false)
  const [userImage, setUserImage] = useState<string | null>(null)
  const [virtualTryOn, setVirtualTryOn] = useState<string | null>(null)
  const [isCameraActive, setIsCameraActive] = useState(false)
  const [videoStream, setVideoStream] = useState<MediaStream | null>(null)
  const { toast } = useToast()

  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setUserImage(reader.result as string)
        processVirtualTryOn(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }, [])

  const processVirtualTryOn = useCallback((image: string) => {
    setIsProcessing(true)
    // Simulate AI processing
    setTimeout(() => {
      setVirtualTryOn(selectedProduct.image)
      setIsProcessing(false)
      toast({
        title: "Virtual Try-On Complete",
        description: "Your virtual fitting has been generated!",
      })
    }, 2000)
  }, [selectedProduct.image, toast])

  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true })
      setVideoStream(stream)
      setIsCameraActive(true)
    } catch (error) {
      toast({
        title: "Camera Error",
        description: "Unable to access camera. Please check permissions.",
        variant: "destructive",
      })
    }
  }, [toast])

  const stopCamera = useCallback(() => {
    if (videoStream) {
      videoStream.getTracks().forEach(track => track.stop())
      setVideoStream(null)
    }
    setIsCameraActive(false)
  }, [videoStream])

  const capturePhoto = useCallback(() => {
    const video = document.querySelector('video')
    const canvas = document.createElement('canvas')
    if (video) {
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight
      canvas.getContext('2d')?.drawImage(video, 0, 0)
      const image = canvas.toDataURL('image/jpeg')
      setUserImage(image)
      processVirtualTryOn(image)
      stopCamera()
    }
  }, [processVirtualTryOn, stopCamera])

  const resetTryOn = useCallback(() => {
    setUserImage(null)
    setVirtualTryOn(null)
    stopCamera()
  }, [stopCamera])

  const shareResult = useCallback(() => {
    // Implement sharing functionality
    toast({
      title: "Share Success",
      description: "Your virtual try-on has been shared!",
    })
  }, [toast])

  return (
    <div className="container py-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-4">Virtual Try-On Experience</h1>
          <p className="text-lg text-muted-foreground">
            See how clothes look on you before you buy using our AR technology
          </p>
        </div>

        <Card className="mb-8">
          <CardContent className="p-6">
            <Tabs defaultValue="upload" className="space-y-4">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="upload">Upload Photo</TabsTrigger>
                <TabsTrigger value="camera">Use Camera</TabsTrigger>
              </TabsList>

              <TabsContent value="upload" className="space-y-4">
                <div className="border-2 border-dashed rounded-lg p-8 text-center">
                  {userImage ? (
                    <div className="relative">
                      <Image
                        src={userImage}
                        alt="Uploaded photo"
                        width={400}
                        height={400}
                        className="mx-auto rounded-lg"
                      />
                      <Button
                        variant="outline"
                        size="icon"
                        className="absolute top-2 right-2"
                        onClick={resetTryOn}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ) : (
                    <>
                      <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                      <h3 className="text-lg font-medium mb-2">Upload Your Photo</h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        Drag and drop your photo here, or click to select
                      </p>
                      <Input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        id="photo-upload"
                        onChange={handleFileUpload}
                      />
                      <Button onClick={() => document.getElementById('photo-upload')?.click()}>
                        Choose File
                      </Button>
                    </>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="camera" className="space-y-4">
                <div className="border-2 border-dashed rounded-lg p-8 text-center">
                  {isCameraActive ? (
                    <div className="relative">
                      <video
                        autoPlay
                        playsInline
                        className="w-full max-w-[400px] mx-auto rounded-lg"
                        ref={video => {
                          if (video && videoStream) {
                            video.srcObject = videoStream
                          }
                        }}
                      />
                      <div className="flex justify-center gap-4 mt-4">
                        <Button onClick={capturePhoto}>
                          <Camera className="mr-2 h-4 w-4" />
                          Take Photo
                        </Button>
                        <Button variant="outline" onClick={stopCamera}>
                          <X className="mr-2 h-4 w-4" />
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <Camera className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                      <h3 className="text-lg font-medium mb-2">Take a Photo</h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        Position yourself in front of the camera
                      </p>
                      <Button onClick={startCamera}>
                        Start Camera
                      </Button>
                    </>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Virtual Try-On Preview */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Preview</h2>
            <div className="aspect-[3/4] relative bg-muted rounded-lg overflow-hidden">
              {isProcessing ? (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4" />
                    <p className="text-sm text-muted-foreground">
                      Generating your virtual try-on...
                    </p>
                  </div>
                </div>
              ) : virtualTryOn ? (
                <Image
                  src={virtualTryOn}
                  alt="Virtual try-on preview"
                  fill
                  className="object-cover"
                />
              ) : (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <Sparkles className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">
                      Upload a photo to see the magic happen
                    </p>
                  </div>
                </div>
              )}
            </div>
            <div className="flex justify-between">
              <Button variant="outline" size="sm" onClick={resetTryOn}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Reset
              </Button>
              <Button variant="outline" size="sm" onClick={shareResult}>
                <Share2 className="h-4 w-4 mr-2" />
                Share
              </Button>
            </div>
          </div>

          {/* Product Selection */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Select Product</h2>
            <div className="grid gap-4">
              {products.map((product) => (
                <Card
                  key={product.id}
                  className={`cursor-pointer transition-colors ${
                    selectedProduct.id === product.id
                      ? "ring-2 ring-primary"
                      : ""
                  }`}
                  onClick={() => {
                    setSelectedProduct(product)
                    if (userImage) {
                      processVirtualTryOn(userImage)
                    }
                  }}
                >
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="relative w-20 h-20">
                      <Image
                        src={product.image}
                        alt={product.name}
                        fill
                        className="object-cover rounded-md"
                      />
                    </div>
                    <div>
                      <h3 className="font-medium">{product.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        ${product.price}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            <Button className="w-full" size="lg">
              Add to Cart
            </Button>
          </div>
        </div>

        {/* Tips */}
        <div className="mt-12 grid md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6 text-center">
              <h3 className="font-medium mb-2">Good Lighting</h3>
              <p className="text-sm text-muted-foreground">
                Ensure you're in a well-lit area for the best results
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <h3 className="font-medium mb-2">Natural Pose</h3>
              <p className="text-sm text-muted-foreground">
                Stand naturally with arms slightly away from your body
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <h3 className="font-medium mb-2">Plain Background</h3>
              <p className="text-sm text-muted-foreground">
                Use a solid color background for better accuracy
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
"use client"

import { useState } from "react"
import Image from "next/image"
import { Heart, Share2, ShoppingCart } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Mock product data (in a real app, this would come from an API)
const product = {
  id: 1,
  name: "Summer Breeze Dress",
  price: 129.99,
  description:
    "A lightweight, flowing dress perfect for summer days. Made from sustainable materials with a focus on comfort and style.",
  images: [
    "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=500&h=500&fit=crop",
    "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=500&h=500&fit=crop",
    "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=500&h=500&fit=crop",
  ],
  sizes: ["XS", "S", "M", "L", "XL"],
  colors: ["White", "Black", "Blue"],
  sustainability: {
    materials: "100% Organic Cotton",
    manufacturing: "Fair Trade Certified",
    carbonFootprint: "Low Impact",
  },
  aiRecommendations: [
    "Pairs well with our Classic Denim Jacket",
    "Perfect for beach vacations",
    "Trending among users with similar style preferences",
  ],
}

export default function ProductPage() {
  const [selectedSize, setSelectedSize] = useState("")
  const [selectedColor, setSelectedColor] = useState("")
  const [mainImage, setMainImage] = useState(product.images[0])

  return (
    <div className="container py-8">
      <div className="grid md:grid-cols-2 gap-8">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="relative aspect-square overflow-hidden rounded-lg">
            <Image
              src={mainImage}
              alt={product.name}
              fill
              className="object-cover"
            />
          </div>
          <div className="grid grid-cols-3 gap-4">
            {product.images.map((image, index) => (
              <button
                key={index}
                onClick={() => setMainImage(image)}
                className="relative aspect-square overflow-hidden rounded-lg"
              >
                <Image
                  src={image}
                  alt={`${product.name} ${index + 1}`}
                  fill
                  className="object-cover"
                />
              </button>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold">{product.name}</h1>
            <p className="text-2xl font-bold mt-2">${product.price}</p>
          </div>

          <p className="text-muted-foreground">{product.description}</p>

          {/* Size Selection */}
          <div>
            <h3 className="font-medium mb-2">Size</h3>
            <div className="flex gap-2">
              {product.sizes.map((size) => (
                <Button
                  key={size}
                  variant={selectedSize === size ? "default" : "outline"}
                  onClick={() => setSelectedSize(size)}
                >
                  {size}
                </Button>
              ))}
            </div>
          </div>

          {/* Color Selection */}
          <div>
            <h3 className="font-medium mb-2">Color</h3>
            <div className="flex gap-2">
              {product.colors.map((color) => (
                <Button
                  key={color}
                  variant={selectedColor === color ? "default" : "outline"}
                  onClick={() => setSelectedColor(color)}
                >
                  {color}
                </Button>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-4">
            <Button size="lg" className="flex-1">
              <ShoppingCart className="mr-2 h-4 w-4" />
              Add to Cart
            </Button>
            <Button size="lg" variant="outline">
              <Heart className="h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline">
              <Share2 className="h-4 w-4" />
            </Button>
          </div>

          {/* Additional Info Tabs */}
          <Tabs defaultValue="sustainability" className="mt-8">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="sustainability">Sustainability</TabsTrigger>
              <TabsTrigger value="recommendations">AI Recommendations</TabsTrigger>
            </TabsList>
            <TabsContent value="sustainability">
              <Card>
                <CardHeader>
                  <CardTitle>Sustainability Information</CardTitle>
                  <CardDescription>
                    Track the environmental impact of this product
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="font-medium">Materials</span>
                    <span>{product.sustainability.materials}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Manufacturing</span>
                    <span>{product.sustainability.manufacturing}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Carbon Footprint</span>
                    <span>{product.sustainability.carbonFootprint}</span>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="recommendations">
              <Card>
                <CardHeader>
                  <CardTitle>Personalized Recommendations</CardTitle>
                  <CardDescription>
                    AI-powered suggestions based on your style
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {product.aiRecommendations.map((rec, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                        {rec}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
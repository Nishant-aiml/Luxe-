"use client"

import { useState, useCallback } from "react"
import Image from "next/image"
import Link from "next/link"
import { 
  Sparkles, 
  ArrowRight, 
  Ruler, 
  Camera, 
  Instagram,
  TrendingUp,
  Upload,
  RefreshCw
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"

const recommendations = [
  {
    id: 1,
    name: "Summer Collection Bundle",
    description: "Based on your style preferences and local weather",
    image: "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=400&h=400&fit=crop",
    price: 299.99,
    matchScore: 98,
  },
  {
    id: 2,
    name: "Workwear Essentials",
    description: "Matches your professional style preferences",
    image: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=400&h=400&fit=crop",
    price: 199.99,
    matchScore: 95,
  },
  {
    id: 3,
    name: "Weekend Casual Set",
    description: "Perfect for your active lifestyle",
    image: "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=400&h=400&fit=crop",
    price: 149.99,
    matchScore: 92,
  },
]

const occasions = [
  {
    name: "Work",
    image: "https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?w=300&h=300&fit=crop",
  },
  {
    name: "Casual",
    image: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=300&h=300&fit=crop",
  },
  {
    name: "Evening",
    image: "https://images.unsplash.com/photo-1490725263030-1f0521cec8ec?w=300&h=300&fit=crop",
  },
  {
    name: "Formal",
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=300&h=300&fit=crop",
  },
]

function RecommendationCard({ item }: { item: typeof recommendations[0] }) {
  return (
    <Card className="overflow-hidden">
      <div className="aspect-square relative">
        <div className="absolute top-2 right-2 z-10">
          <span className="px-3 py-1 bg-background/95 rounded-full text-sm font-medium backdrop-blur-sm">
            {item.matchScore}% Match
          </span>
        </div>
        <Image
          src={item.image}
          alt={item.name}
          fill
          className="object-cover"
        />
      </div>
      <CardContent className="p-4">
        <h3 className="font-medium mb-1">{item.name}</h3>
        <p className="text-sm text-muted-foreground mb-3">
          {item.description}
        </p>
        <div className="flex items-center justify-between">
          <span className="font-bold">${item.price}</span>
          <Button size="sm">View Details</Button>
        </div>
      </CardContent>
    </Card>
  )
}

function OccasionCard({ occasion }: { occasion: typeof occasions[0] }) {
  return (
    <div className="relative aspect-square rounded-lg overflow-hidden group cursor-pointer">
      <Image
        src={occasion.image}
        alt={occasion.name}
        fill
        className="object-cover transition-transform group-hover:scale-105"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent flex items-end p-4">
        <h3 className="text-lg font-medium text-white">{occasion.name}</h3>
      </div>
    </div>
  )
}

export default function PersonalizedPage() {
  const [styleProfile, setStyleProfile] = useState(85)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const { toast } = useToast()

  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setSelectedFile(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }, [])

  const analyzeStyle = useCallback(async () => {
    if (!selectedFile) {
      toast({
        title: "No image selected",
        description: "Please upload an image to analyze your style.",
        variant: "destructive",
      })
      return
    }

    setIsAnalyzing(true)
    // Simulate AI analysis
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    toast({
      title: "Style Analysis Complete",
      description: "We've updated your recommendations based on your style preferences.",
    })
    
    setStyleProfile(prev => Math.min(prev + 10, 100))
    setIsAnalyzing(false)
  }, [selectedFile, toast])

  return (
    <div className="container py-8">
      {/* Style Profile Overview */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-2xl font-bold mb-2">Your Style Profile</h2>
              <p className="text-muted-foreground mb-6">
                AI-powered recommendations based on your preferences and behavior
              </p>
              <div className="space-y-6">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Profile Completion</span>
                    <span className="text-sm text-muted-foreground">{styleProfile}%</span>
                  </div>
                  <Progress value={styleProfile} className="h-2" />
                </div>

                {/* Image Upload Section */}
                <div className="space-y-4">
                  <h3 className="font-medium">Upload Your Style Photo</h3>
                  <div className="border-2 border-dashed rounded-lg p-4">
                    {previewUrl ? (
                      <div className="relative aspect-square w-full max-w-[200px] mx-auto mb-4">
                        <Image
                          src={previewUrl}
                          alt="Style preview"
                          fill
                          className="object-cover rounded-lg"
                        />
                      </div>
                    ) : (
                      <div className="text-center p-4">
                        <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">
                          Drag and drop or click to upload
                        </p>
                      </div>
                    )}
                    <div className="flex gap-2 justify-center">
                      <Input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        id="style-upload"
                        onChange={handleFileChange}
                      />
                      <Button
                        variant="outline"
                        onClick={() => document.getElementById("style-upload")?.click()}
                      >
                        Choose File
                      </Button>
                      <Button
                        onClick={analyzeStyle}
                        disabled={!selectedFile || isAnalyzing}
                      >
                        {isAnalyzing ? (
                          <>
                            <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                            Analyzing...
                          </>
                        ) : (
                          <>
                            <Sparkles className="mr-2 h-4 w-4" />
                            Analyze Style
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button variant="outline" className="flex-1">
                    <Ruler className="mr-2 h-4 w-4" />
                    Update Measurements
                  </Button>
                  <Button variant="outline" className="flex-1">
                    <Camera className="mr-2 h-4 w-4" />
                    Take Photo
                  </Button>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <h3 className="font-medium">Connected Services</h3>
              <div className="grid gap-4">
                <Card>
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Instagram className="h-5 w-5" />
                      <div>
                        <p className="font-medium">Instagram</p>
                        <p className="text-sm text-muted-foreground">Style analysis from your posts</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">Manage</Button>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <TrendingUp className="h-5 w-5" />
                      <div>
                        <p className="font-medium">Style Preferences</p>
                        <p className="text-sm text-muted-foreground">Based on your interactions</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">Update</Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recommendations */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">Personalized For You</h2>
          <Button variant="ghost" asChild>
            <Link href="/shop/recommendations">
              View All
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>

        <Tabs defaultValue="outfits" className="space-y-6">
          <TabsList>
            <TabsTrigger value="outfits">Complete Outfits</TabsTrigger>
            <TabsTrigger value="items">Individual Items</TabsTrigger>
            <TabsTrigger value="occasions">By Occasion</TabsTrigger>
          </TabsList>

          <TabsContent value="outfits">
            <div className="grid md:grid-cols-3 gap-6">
              {recommendations.map((item) => (
                <RecommendationCard key={item.id} item={item} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="occasions">
            <div className="grid md:grid-cols-4 gap-6">
              {occasions.map((occasion) => (
                <OccasionCard key={occasion.name} occasion={occasion} />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Style Tips */}
      <Card className="mt-8">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="h-5 w-5" />
            <h2 className="text-xl font-bold">AI Style Tips</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="p-4 bg-muted rounded-lg">
              <h3 className="font-medium mb-2">Color Palette</h3>
              <p className="text-sm text-muted-foreground">
                Based on your skin tone and preferences, warm earth tones and jewel colors
                will complement your look best.
              </p>
            </div>
            <div className="p-4 bg-muted rounded-lg">
              <h3 className="font-medium mb-2">Silhouette Analysis</h3>
              <p className="text-sm text-muted-foreground">
                A-line dresses and high-waisted styles flatter your body type and align
                with your style preferences.
              </p>
            </div>
            <div className="p-4 bg-muted rounded-lg">
              <h3 className="font-medium mb-2">Trending For You</h3>
              <p className="text-sm text-muted-foreground">
                Statement accessories and layered looks are trending among users with
                similar style profiles.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
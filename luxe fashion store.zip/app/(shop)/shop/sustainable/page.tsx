"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { 
  Leaf, 
  Recycle, 
  Globe, 
  Heart,
  Filter,
  ArrowUpDown
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet"

const products = [
  {
    id: 1,
    name: "Organic Cotton Dress",
    price: 129.99,
    image: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=500&h=500&fit=crop",
    sustainability: {
      score: 95,
      materials: "100% Organic Cotton",
      impact: "Low Water Usage",
      certification: "GOTS Certified",
    },
  },
  {
    id: 2,
    name: "Recycled Denim Jacket",
    price: 159.99,
    image: "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=500&h=500&fit=crop",
    sustainability: {
      score: 90,
      materials: "80% Recycled Denim",
      impact: "Saves 2000L Water",
      certification: "Recycled Claim Standard",
    },
  },
  {
    id: 3,
    name: "Hemp Blend Shirt",
    price: 79.99,
    image: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=500&h=500&fit=crop",
    sustainability: {
      score: 98,
      materials: "Hemp and Organic Cotton",
      impact: "Carbon Negative",
      certification: "Fair Trade",
    },
  },
]

const certifications = [
  { value: "all", label: "All Certifications" },
  { value: "gots", label: "GOTS Certified" },
  { value: "fairtrade", label: "Fair Trade" },
  { value: "recycled", label: "Recycled Claim Standard" },
]

const impacts = [
  { value: "all", label: "All Impact Levels" },
  { value: "low", label: "Low Impact" },
  { value: "neutral", label: "Carbon Neutral" },
  { value: "negative", label: "Carbon Negative" },
]

function ProductCard({ product }: { product: typeof products[0] }) {
  return (
    <Card className="overflow-hidden group">
      <div className="aspect-square relative">
        <div className="absolute top-2 right-2 z-10">
          <span className="px-3 py-1 bg-background/95 rounded-full text-sm font-medium backdrop-blur-sm flex items-center gap-1">
            <Leaf className="h-4 w-4 text-green-600" />
            {product.sustainability.score}%
          </span>
        </div>
        <Image
          src={product.image}
          alt={product.name}
          fill
          className="object-cover transition-transform group-hover:scale-105"
        />
      </div>
      <CardContent className="p-4">
        <h3 className="font-medium mb-1">{product.name}</h3>
        <p className="text-sm text-muted-foreground mb-3">
          {product.sustainability.materials}
        </p>
        <div className="flex items-center justify-between">
          <span className="font-bold">${product.price}</span>
          <Button size="sm">View Details</Button>
        </div>
        <div className="mt-4 pt-4 border-t grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="font-medium">Impact</p>
            <p className="text-muted-foreground">{product.sustainability.impact}</p>
          </div>
          <div>
            <p className="font-medium">Certification</p>
            <p className="text-muted-foreground">{product.sustainability.certification}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default function SustainablePage() {
  const [sortBy, setSortBy] = useState("recommended")

  return (
    <div className="container py-8">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Sustainable Fashion Marketplace</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Shop ethically-sourced, eco-friendly fashion that makes a positive impact
          on our planet and its people.
        </p>
      </div>

      {/* Impact Stats */}
      <div className="grid md:grid-cols-3 gap-6 mb-12">
        <Card>
          <CardContent className="p-6 text-center">
            <Recycle className="h-8 w-8 mx-auto mb-4 text-green-600" />
            <h3 className="font-medium mb-2">Recycled Materials</h3>
            <p className="text-2xl font-bold mb-1">12.5K kg</p>
            <p className="text-sm text-muted-foreground">
              Materials saved from landfills
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6 text-center">
            <Globe className="h-8 w-8 mx-auto mb-4 text-blue-600" />
            <h3 className="font-medium mb-2">Water Saved</h3>
            <p className="text-2xl font-bold mb-1">1.2M L</p>
            <p className="text-sm text-muted-foreground">
              Through sustainable practices
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6 text-center">
            <Heart className="h-8 w-8 mx-auto mb-4 text-red-600" />
            <h3 className="font-medium mb-2">Artisan Support</h3>
            <p className="text-2xl font-bold mb-1">850+</p>
            <p className="text-sm text-muted-foreground">
              Artisans supported globally
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Sort */}
      <div className="flex items-center justify-between mb-6">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline">
              <Filter className="mr-2 h-4 w-4" />
              Filters
            </Button>
          </SheetTrigger>
          <SheetContent>
            <SheetHeader>
              <SheetTitle>Filter Products</SheetTitle>
            </SheetHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <h3 className="text-sm font-medium">Certification</h3>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select certification" />
                  </SelectTrigger>
                  <SelectContent>
                    {certifications.map((cert) => (
                      <SelectItem key={cert.value} value={cert.value}>
                        {cert.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <h3 className="text-sm font-medium">Environmental Impact</h3>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select impact level" />
                  </SelectTrigger>
                  <SelectContent>
                    {impacts.map((impact) => (
                      <SelectItem key={impact.value} value={impact.value}>
                        {impact.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </SheetContent>
        </Sheet>

        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-[180px]">
            <ArrowUpDown className="mr-2 h-4 w-4" />
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="recommended">Recommended</SelectItem>
            <SelectItem value="impact">Highest Impact</SelectItem>
            <SelectItem value="price-low">Price: Low to High</SelectItem>
            <SelectItem value="price-high">Price: High to Low</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Product Grid */}
      <div className="grid md:grid-cols-3 gap-6">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      {/* Sustainability Guide */}
      <Card className="mt-12">
        <CardContent className="p-6">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-2xl font-bold mb-4">Our Sustainability Guide</h2>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Leaf className="h-5 w-5 text-green-600 mt-1" />
                  <div>
                    <h3 className="font-medium">Materials Matter</h3>
                    <p className="text-sm text-muted-foreground">
                      We carefully select eco-friendly materials that minimize
                      environmental impact while maximizing durability.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Globe className="h-5 w-5 text-blue-600 mt-1" />
                  <div>
                    <h3 className="font-medium">Transparent Supply Chain</h3>
                    <p className="text-sm text-muted-foreground">
                      Track your garment's journey from source to wardrobe with
                      our blockchain-based transparency system.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Heart className="h-5 w-5 text-red-600 mt-1" />
                  <div>
                    <h3 className="font-medium">Fair Labor Practices</h3>
                    <p className="text-sm text-muted-foreground">
                      We ensure fair wages and safe working conditions throughout
                      our supply chain.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative aspect-[4/3] rounded-lg overflow-hidden">
              <Image
                src="https://images.unsplash.com/photo-1532202802379-df93d543bac3?w=800&h=600&fit=crop"
                alt="Sustainable fashion production"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
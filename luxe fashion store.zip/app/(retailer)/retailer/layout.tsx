"use client"

import { useState } from "react"
import Link from "next/link"
import { Store } from "lucide-react"
import { ThemeProvider } from "@/components/theme-provider"

export default function RetailerLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <ThemeProvider
      attribute="class"
      defaultTheme="system"
      enableSystem
      disableTransitionOnChange
    >
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
        <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-14 items-center">
            <Link href="/" className="flex items-center gap-2">
              <Store className="h-6 w-6" />
              <span className="font-bold">LUXE Retailer</span>
            </Link>
          </div>
        </header>
        <main>{children}</main>
      </div>
    </ThemeProvider>
  )
}
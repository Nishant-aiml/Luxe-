import { createClient } from '@libsql/client'

const db = createClient({
  url: process.env.TURSO_DATABASE_URL || 'file:local.db',
  authToken: process.env.TURSO_AUTH_TOKEN,
})

export class DBService {
  static async createUser(userData: {
    email: string
    passwordHash: string
    name: string
    role: string
  }) {
    try {
      const result = await db.execute({
        sql: `INSERT INTO users (email, password_hash, name, role) VALUES (?, ?, ?, ?)`,
        args: [userData.email, userData.passwordHash, userData.name, userData.role],
      })
      return result.lastInsertId
    } catch (error) {
      console.error('Database error:', error)
      throw new Error('Failed to create user')
    }
  }

  static async getUserByEmail(email: string) {
    try {
      const result = await db.execute({
        sql: `SELECT * FROM users WHERE email = ?`,
        args: [email],
      })
      return result.rows[0]
    } catch (error) {
      console.error('Database error:', error)
      throw new Error('Failed to get user')
    }
  }

  static async saveOrder(orderData: {
    userId: string
    items: any[]
    total: number
    transactionHash: string
  }) {
    try {
      const result = await db.execute({
        sql: `INSERT INTO orders (user_id, items, total, transaction_hash) VALUES (?, ?, ?, ?)`,
        args: [
          orderData.userId,
          JSON.stringify(orderData.items),
          orderData.total,
          orderData.transactionHash,
        ],
      })
      return result.lastInsertId
    } catch (error) {
      console.error('Database error:', error)
      throw new Error('Failed to save order')
    }
  }

  static async getUserOrders(userId: string) {
    try {
      const result = await db.execute({
        sql: `SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC`,
        args: [userId],
      })
      return result.rows
    } catch (error) {
      console.error('Database error:', error)
      throw new Error('Failed to get user orders')
    }
  }
}
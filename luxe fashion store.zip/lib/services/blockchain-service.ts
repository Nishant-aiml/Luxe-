import { ethers } from 'ethers'
import type { TransactionResponse } from '@ethersproject/abstract-provider'

declare global {
  interface Window {
    ethereum?: any;
  }
}

// ABI for the smart contract (simplified for example)
const CONTRACT_ABI = [
  "function processPayment(uint256 amount) public payable returns (bool)",
  "function verifyUser(address userAddress) public view returns (bool)",
]

const CONTRACT_ADDRESS = process.env.NEXT_PUBLIC_CONTRACT_ADDRESS || ''

export class BlockchainService {
  private static provider: ethers.providers.Web3Provider
  private static contract: ethers.Contract

  static async initialize() {
    if (typeof window === 'undefined') return

    // Check if MetaMask is installed
    if (!window.ethereum) {
      throw new Error('MetaMask is not installed')
    }

    try {
      // Request account access
      await window.ethereum.request({ method: 'eth_requestAccounts' })
      
      this.provider = new ethers.providers.Web3Provider(window.ethereum)
      const signer = this.provider.getSigner()
      
      this.contract = new ethers.Contract(
        CONTRACT_ADDRESS,
        CONTRACT_ABI,
        signer
      )
    } catch (error) {
      console.error('Blockchain initialization error:', error)
      throw new Error('Failed to initialize blockchain service')
    }
  }

  static async processPayment(amount: number): Promise<TransactionResponse> {
    try {
      if (!this.contract) {
        await this.initialize()
      }

      const amountWei = ethers.utils.parseEther(amount.toString())
      const transaction = await this.contract.processPayment(amountWei, {
        value: amountWei,
      })

      return transaction
    } catch (error) {
      console.error('Payment processing error:', error)
      throw new Error('Failed to process payment')
    }
  }

  static async verifyUser(address: string): Promise<boolean> {
    try {
      if (!this.contract) {
        await this.initialize()
      }

      const isVerified = await this.contract.verifyUser(address)
      return isVerified
    } catch (error) {
      console.error('User verification error:', error)
      throw new Error('Failed to verify user')
    }
  }

  static async getCurrentAddress(): Promise<string> {
    try {
      if (!this.provider) {
        await this.initialize()
      }

      const signer = this.provider.getSigner()
      return await signer.getAddress()
    } catch (error) {
      console.error('Get address error:', error)
      throw new Error('Failed to get current address')
    }
  }

  static async signMessage(message: string): Promise<string> {
    try {
      if (!this.provider) {
        await this.initialize()
      }

      const signer = this.provider.getSigner()
      const signature = await signer.signMessage(message)
      return signature
    } catch (error) {
      console.error('Message signing error:', error)
      throw new Error('Failed to sign message')
    }
  }
}
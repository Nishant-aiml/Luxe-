import { NextRequest } from 'next/server'

export type UserRole = 'customer' | 'retailer'

export interface AuthUser {
  id: string
  email: string
  role: UserRole
  name: string
}

export async function validateAuth(request: NextRequest): Promise<AuthUser | null> {
  const token = request.cookies.get('authToken')?.value

  if (!token) {
    return null
  }

  try {
    // In a real app, verify the JWT token and decode user information
    // This is a simplified example
    const user: AuthUser = {
      id: '1',
      email: 'user@example.com',
      role: 'customer',
      name: 'John Doe',
    }

    return user
  } catch (error) {
    console.error('Auth validation error:', error)
    return null
  }
}

export function isRetailerRoute(pathname: string): boolean {
  return pathname.startsWith('/dashboard') || 
         pathname.startsWith('/retailer')
}

export function isCustomerRoute(pathname: string): boolean {
  return pathname.startsWith('/shop') || 
         pathname === '/login' || 
         pathname === '/register'
}

export function getRedirectUrl(role: UserRole): string {
  return role === 'retailer' ? '/dashboard' : '/shop'
}
"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { Camera, X, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"

interface CameraCaptureProps {
  onCapture: (image: string) => void
  onClose: () => void
}

export function CameraCapture({ onCapture, onClose }: CameraCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [isInitializing, setIsInitializing] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const initCamera = async () => {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { 
            facingMode: "user",
            width: { ideal: 1280 },
            height: { ideal: 720 }
          },
        })
        setStream(mediaStream)
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream
        }
      } catch (error) {
        console.error('Camera initialization error:', error)
        toast({
          title: "Camera Error",
          description: "Unable to access camera. Please check permissions.",
          variant: "destructive",
        })
        onClose()
      } finally {
        setIsInitializing(false)
      }
    }

    initCamera()

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop())
      }
    }
  }, [onClose, toast, stream])

  const handleCapture = useCallback(() => {
    if (videoRef.current) {
      const canvas = document.createElement("canvas")
      canvas.width = videoRef.current.videoWidth
      canvas.height = videoRef.current.videoHeight
      const ctx = canvas.getContext("2d")
      if (ctx) {
        // Flip the image horizontally if using front camera
        ctx.translate(canvas.width, 0)
        ctx.scale(-1, 1)
        ctx.drawImage(videoRef.current, 0, 0)
        
        // Convert to base64
        const image = canvas.toDataURL("image/jpeg", 0.8)
        onCapture(image)
      }
    }
  }, [onCapture])

  const switchCamera = useCallback(async () => {
    if (stream) {
      const currentFacingMode = stream.getVideoTracks()[0].getSettings().facingMode
      const newFacingMode = currentFacingMode === "user" ? "environment" : "user"
      
      // Stop current stream
      stream.getTracks().forEach(track => track.stop())
      
      try {
        const newStream = await navigator.mediaDevices.getUserMedia({
          video: { 
            facingMode: newFacingMode,
            width: { ideal: 1280 },
            height: { ideal: 720 }
          },
        })
        setStream(newStream)
        if (videoRef.current) {
          videoRef.current.srcObject = newStream
        }
      } catch (error) {
        console.error('Camera switch error:', error)
        toast({
          title: "Camera Error",
          description: "Unable to switch camera. Please try again.",
          variant: "destructive",
        })
      }
    }
  }, [stream, toast])

  return (
    <div className="relative">
      {isInitializing ? (
        <div className="flex items-center justify-center h-[300px]">
          <RefreshCw className="h-8 w-8 animate-spin" />
        </div>
      ) : (
        <>
          <video
            ref={videoRef}
            autoPlay
            playsInline
            className="w-full max-w-[400px] mx-auto rounded-lg transform scale-x-[-1]"
          />
          <div className="absolute top-2 right-2 flex gap-2">
            <Button
              variant="outline"
              size="icon"
              className="bg-background/80 backdrop-blur-sm"
              onClick={switchCamera}
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="bg-background/80 backdrop-blur-sm"
              onClick={onClose}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex justify-center gap-4 mt-4">
            <Button onClick={handleCapture}>
              <Camera className="mr-2 h-4 w-4" />
              Take Photo
            </Button>
          </div>
        </>
      )}
    </div>
  )
}
"use client"

import { useState, useEffect } from "react"
import { Ruler, Save, Camera, Upload, RefreshCw } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { AIService } from "@/lib/services/ai-service"
import { CameraCapture } from "@/components/camera/CameraCapture"

interface Measurements {
  height: number
  shoulders: number
  chest: number
  waist: number
  hips: number
}

export function MeasurementModal() {
  const [measurements, setMeasurements] = useState<Measurements>({
    height: 0,
    shoulders: 0,
    chest: 0,
    waist: 0,
    hips: 0,
  })
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [showCamera, setShowCamera] = useState(false)
  const [photoUrl, setPhotoUrl] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    // Load saved measurements from localStorage
    const savedMeasurements = localStorage.getItem('userMeasurements')
    if (savedMeasurements) {
      setMeasurements(JSON.parse(savedMeasurements))
    }
  }, [])

  const handleSave = async () => {
    // Validate measurements
    if (Object.values(measurements).some(value => value <= 0)) {
      toast({
        title: "Invalid measurements",
        description: "Please enter valid measurements for all fields.",
        variant: "destructive",
      })
      return
    }

    setIsAnalyzing(true)
    try {
      // Analyze measurements using AI service
      const analysis = await AIService.analyzeMeasurements(measurements)
      
      // Save measurements
      localStorage.setItem("userMeasurements", JSON.stringify(measurements))
      
      toast({
        title: "Measurements saved",
        description: "Your measurements have been updated successfully.",
      })

      // Show size recommendations
      toast({
        title: "Size Recommendations",
        description: `Tops: ${analysis.sizeRecommendations.tops}, Bottoms: ${analysis.sizeRecommendations.bottoms}`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to analyze measurements. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsAnalyzing(false)
    }
  }

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setPhotoUrl(reader.result as string)
        analyzePhoto(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handlePhotoCapture = (photoData: string) => {
    setPhotoUrl(photoData)
    setShowCamera(false)
    analyzePhoto(photoData)
  }

  const analyzePhoto = async (photoData: string) => {
    setIsAnalyzing(true)
    try {
      const analysis = await AIService.analyzeImage(photoData)
      setMeasurements(analysis.measurements)
      
      toast({
        title: "Photo Analysis Complete",
        description: "Measurements have been updated based on your photo.",
      })
    } catch (error) {
      toast({
        title: "Analysis Error",
        description: "Failed to analyze photo. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline">
          <Ruler className="mr-2 h-4 w-4" />
          Update Measurements
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Update Measurements</DialogTitle>
          <DialogDescription>
            Enter your measurements in centimeters for the best fit recommendations.
          </DialogDescription>
        </DialogHeader>

        {showCamera ? (
          <CameraCapture
            onCapture={handlePhotoCapture}
            onClose={() => setShowCamera(false)}
          />
        ) : (
          <>
            {photoUrl && (
              <div className="relative w-full aspect-square mb-4">
                <img
                  src={photoUrl}
                  alt="Measurement photo"
                  className="rounded-lg object-cover w-full h-full"
                />
              </div>
            )}

            <div className="flex gap-2 mb-4">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setShowCamera(true)}
              >
                <Camera className="mr-2 h-4 w-4" />
                Take Photo
              </Button>
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => document.getElementById('photo-upload')?.click()}
              >
                <Upload className="mr-2 h-4 w-4" />
                Upload Photo
              </Button>
              <input
                id="photo-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handlePhotoUpload}
              />
            </div>

            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="height" className="text-right">
                  Height
                </Label>
                <Input
                  id="height"
                  type="number"
                  className="col-span-3"
                  value={measurements.height}
                  onChange={(e) =>
                    setMeasurements((prev) => ({
                      ...prev,
                      height: parseFloat(e.target.value),
                    }))
                  }
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="shoulders" className="text-right">
                  Shoulders
                </Label>
                <Input
                  id="shoulders"
                  type="number"
                  className="col-span-3"
                  value={measurements.shoulders}
                  onChange={(e) =>
                    setMeasurements((prev) => ({
                      ...prev,
                      shoulders: parseFloat(e.target.value),
                    }))
                  }
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="chest" className="text-right">
                  Chest
                </Label>
                <Input
                  id="chest"
                  type="number"
                  className="col-span-3"
                  value={measurements.chest}
                  onChange={(e) =>
                    setMeasurements((prev) => ({
                      ...prev,
                      chest: parseFloat(e.target.value),
                    }))
                  }
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="waist" className="text-right">
                  Waist
                </Label>
                <Input
                  id="waist"
                  type="number"
                  className="col-span-3"
                  value={measurements.waist}
                  onChange={(e) =>
                    setMeasurements((prev) => ({
                      ...prev,
                      waist: parseFloat(e.target.value),
                    }))
                  }
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="hips" className="text-right">
                  Hips
                </Label>
                <Input
                  id="hips"
                  type="number"
                  className="col-span-3"
                  value={measurements.hips}
                  onChange={(e) =>
                    setMeasurements((prev) => ({
                      ...prev,
                      hips: parseFloat(e.target.value),
                    }))
                  }
                />
              </div>
            </div>

            <div className="flex justify-end">
              <Button onClick={handleSave} disabled={isAnalyzing}>
                {isAnalyzing ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Save Measurements
                  </>
                )}
              </Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}
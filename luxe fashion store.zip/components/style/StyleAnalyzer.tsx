"use client"

import { useState, useCallback } from "react"
import Image from "next/image"
import { Camera, Upload, RefreshCw, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { useStyleEngine } from "@/hooks/use-style-engine"
import { CameraCapture } from "@/components/camera/CameraCapture"
import { MeasurementModal } from "@/components/measurement/MeasurementModal"

export function StyleAnalyzer() {
  const [photo, setPhoto] = useState<string | null>(null)
  const [showCamera, setShowCamera] = useState(false)
  const { isAnalyzing, suggestions, analyzeMeasurements } = useStyleEngine()
  const { toast } = useToast()

  const handlePhotoUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setPhoto(reader.result as string)
        processStyleAnalysis(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }, [])

  const handlePhotoCapture = useCallback((photoData: string) => {
    setPhoto(photoData)
    setShowCamera(false)
    processStyleAnalysis(photoData)
  }, [])

  const processStyleAnalysis = useCallback(async (photoData: string) => {
    // Get measurements from localStorage
    const savedMeasurements = localStorage.getItem('userMeasurements')
    if (!savedMeasurements) {
      toast({
        title: "Measurements Required",
        description: "Please update your measurements first.",
        variant: "destructive",
      })
      return
    }

    const measurements = JSON.parse(savedMeasurements)
    const preferences = {
      colors: ["navy", "black", "white"],
      patterns: ["solid", "striped"],
      fits: ["regular", "slim"],
    }

    await analyzeMeasurements(measurements, preferences, "female")
  }, [analyzeMeasurements, toast])

  return (
    <div className="space-y-6">
      {showCamera ? (
        <CameraCapture
          onCapture={handlePhotoCapture}
          onClose={() => setShowCamera(false)}
        />
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Style Analysis</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4 justify-center">
              <Button
                variant="outline"
                onClick={() => setShowCamera(true)}
              >
                <Camera className="mr-2 h-4 w-4" />
                Take Photo
              </Button>
              <Button
                variant="outline"
                onClick={() => document.getElementById('style-photo')?.click()}
              >
                <Upload className="mr-2 h-4 w-4" />
                Upload Photo
              </Button>
              <MeasurementModal />
              <Input
                id="style-photo"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handlePhotoUpload}
              />
            </div>

            {photo && (
              <div className="relative aspect-square max-w-md mx-auto">
                <Image
                  src={photo}
                  alt="Style photo"
                  fill
                  className="object-cover rounded-lg"
                />
              </div>
            )}

            {isAnalyzing && (
              <div className="text-center py-8">
                <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4" />
                <p className="text-sm text-muted-foreground">
                  Analyzing your style preferences...
                </p>
              </div>
            )}

            {suggestions.length > 0 && (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {suggestions.map((suggestion) => (
                  <Card key={suggestion.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Sparkles className="h-4 w-4" />
                        <h3 className="font-medium">{suggestion.name}</h3>
                      </div>
                      <p className="text-sm text-muted-foreground mb-4">
                        {suggestion.description}
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        {suggestion.items.map((item) => (
                          <div key={item.id} className="relative aspect-square">
                            <Image
                              src={item.image}
                              alt={item.name}
                              fill
                              className="object-cover rounded-md"
                            />
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
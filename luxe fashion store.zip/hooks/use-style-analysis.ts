import { useState, useCallback } from "react"
import { AIService } from "@/lib/services/ai-service"
import { useToast } from "@/components/ui/use-toast"
import type { UserProfile } from "@/types/user"

export function useStyleAnalysis() {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const { toast } = useToast()

  const analyzeImage = useCallback(async (imageData: string) => {
    setIsAnalyzing(true)
    try {
      // First, analyze the image using AI
      const analysis = await AIService.analyzeImage(imageData)
      
      // Get personalized recommendations based on analysis
      const recommendations = await AIService.getPersonalizedRecommendations(
        analysis.measurements,
        analysis.stylePreferences,
        analysis.gender
      )
      
      // Save user profile with measurements and preferences
      const profile: UserProfile = {
        id: Date.now().toString(),
        ...analysis,
      }
      setUserProfile(profile)
      
      // Save to local storage for persistence
      localStorage.setItem('userProfile', JSON.stringify(profile))

      toast({
        title: "Style Analysis Complete",
        description: "Your personalized recommendations are ready!",
      })

      return {
        profile,
        recommendations,
      }
    } catch (error) {
      console.error('Style analysis error:', error)
      toast({
        title: "Analysis Error",
        description: "Failed to analyze style. Please try again.",
        variant: "destructive",
      })
      return null
    } finally {
      setIsAnalyzing(false)
    }
  }, [toast])

  const loadSavedProfile = useCallback(() => {
    const savedProfile = localStorage.getItem('userProfile')
    if (savedProfile) {
      setUserProfile(JSON.parse(savedProfile))
    }
    return savedProfile ? JSON.parse(savedProfile) : null
  }, [])

  return {
    isAnalyzing,
    userProfile,
    analyzeImage,
    loadSavedProfile,
  }
}
"use client"

import { useState, useCallback } from "react"
import { useRouter } from "next/navigation"
import { DBService } from "@/lib/services/db-service"
import { BlockchainService } from "@/lib/services/blockchain-service"
import { useToast } from "@/components/ui/use-toast"

export function useAuth() {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  const login = useCallback(async (email: string, password: string) => {
    setIsLoading(true)
    try {
      // Initialize blockchain service
      await BlockchainService.initialize()
      
      // Get user from database
      const user = await DBService.getUserByEmail(email)
      if (!user) {
        throw new Error('User not found')
      }

      // Get wallet address and verify
      const address = await BlockchainService.getCurrentAddress()
      const isVerified = await BlockchainService.verifyUser(address)

      if (!isVerified) {
        throw new Error('Wallet not verified')
      }

      // Sign message for additional security
      const message = `Login to LUXE with email: ${email}`
      const signature = await BlockchainService.signMessage(message)

      // Store auth data in localStorage
      localStorage.setItem('authUser', JSON.stringify({
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        walletAddress: address,
        signature,
      }))

      toast({
        title: "Login successful",
        description: "Welcome back to LUXE!",
      })

      // Redirect based on user role
      router.push(user.role === 'retailer' ? '/dashboard' : '/shop')
    } catch (error) {
      console.error('Login error:', error)
      toast({
        title: "Login failed",
        description: error instanceof Error ? error.message : "Please try again",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }, [router, toast])

  const register = useCallback(async (userData: {
    email: string
    password: string
    name: string
    role: string
  }) => {
    setIsLoading(true)
    try {
      // Initialize blockchain service
      await BlockchainService.initialize()
      
      // Get wallet address
      const address = await BlockchainService.getCurrentAddress()
      
      // Create user in database
      const userId = await DBService.createUser({
        ...userData,
        passwordHash: await hashPassword(userData.password),
      })

      // Sign message for wallet verification
      const message = `Register to LUXE with email: ${userData.email}`
      const signature = await BlockchainService.signMessage(message)

      toast({
        title: "Registration successful",
        description: "Please log in to continue.",
      })

      router.push('/login')
    } catch (error) {
      console.error('Registration error:', error)
      toast({
        title: "Registration failed",
        description: error instanceof Error ? error.message : "Please try again",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }, [router, toast])

  const logout = useCallback(() => {
    localStorage.removeItem('authUser')
    router.push('/')
  }, [router])

  return {
    isLoading,
    login,
    register,
    logout,
  }
}

// Helper function to hash password (in a real app, use a proper hashing library)
async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder()
  const data = encoder.encode(password)
  const hash = await crypto.subtle.digest('SHA-256', data)
  return Array.from(new Uint8Array(hash))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
}
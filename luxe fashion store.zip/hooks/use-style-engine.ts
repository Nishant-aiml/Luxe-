"use client"

import { useState, useCallback } from "react"
import { AIService } from "@/lib/services/ai-service"
import { useToast } from "@/components/ui/use-toast"
import type { Gender, StylePreferences, UserMeasurements } from "@/types/user"

interface StyleSuggestion {
  id: string
  name: string
  confidence: number
  items: {
    id: string
    name: string
    image: string
    price: number
  }[]
  description: string
}

export function useStyleEngine() {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [suggestions, setSuggestions] = useState<StyleSuggestion[]>([])
  const { toast } = useToast()

  const analyzeMeasurements = useCallback(async (
    measurements: UserMeasurements,
    preferences: StylePreferences,
    gender: Gender
  ) => {
    setIsAnalyzing(true)
    try {
      const recommendations = await AIService.getPersonalizedRecommendations(
        measurements,
        preferences,
        gender
      )

      setSuggestions(recommendations.outfits.map(outfit => ({
        id: outfit.id.toString(),
        name: outfit.name,
        confidence: outfit.confidence,
        items: recommendations.items.map(item => ({
          id: item.id.toString(),
          name: item.name,
          image: `https://images.unsplash.com/photo-${item.id}`,
          price: 99.99 // In a real app, this would come from the database
        })),
        description: `AI-curated outfit based on your style preferences and measurements. 
          Confidence score: ${(outfit.confidence * 100).toFixed(1)}%`
      })))

      toast({
        title: "Style Analysis Complete",
        description: "Your personalized recommendations are ready!",
      })

      return recommendations
    } catch (error) {
      console.error('Style analysis error:', error)
      toast({
        title: "Analysis Error",
        description: "Failed to analyze style preferences. Please try again.",
        variant: "destructive",
      })
      return null
    } finally {
      setIsAnalyzing(false)
    }
  }, [toast])

  const updatePreferences = useCallback(async (preferences: StylePreferences) => {
    try {
      await AIService.updateStylePreferences(preferences)
      toast({
        title: "Preferences Updated",
        description: "Your style preferences have been saved.",
      })
      return true
    } catch (error) {
      console.error('Update preferences error:', error)
      toast({
        title: "Update Error",
        description: "Failed to update preferences. Please try again.",
        variant: "destructive",
      })
      return false
    }
  }, [toast])

  return {
    isAnalyzing,
    suggestions,
    analyzeMeasurements,
    updatePreferences,
  }
}
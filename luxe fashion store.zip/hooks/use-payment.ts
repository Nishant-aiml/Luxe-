"use client"

import { useState, useCallback } from "react"
import { DBService } from "@/lib/services/db-service"
import { BlockchainService } from "@/lib/services/blockchain-service"
import { useToast } from "@/components/ui/use-toast"

export function usePayment() {
  const [isProcessing, setIsProcessing] = useState(false)
  const { toast } = useToast()

  const processPayment = useCallback(async (orderData: {
    items: any[]
    total: number
  }) => {
    setIsProcessing(true)
    try {
      // Get user data from localStorage
      const authUser = localStorage.getItem('authUser')
      if (!authUser) {
        throw new Error('User not authenticated')
      }
      const { id: userId } = JSON.parse(authUser)

      // Initialize blockchain service
      await BlockchainService.initialize()

      // Process payment through smart contract
      const transaction = await BlockchainService.processPayment(orderData.total)
      
      // Wait for transaction confirmation
      const receipt = await transaction.wait()

      // Save order to database with transaction hash
      await DBService.saveOrder({
        userId,
        items: orderData.items,
        total: orderData.total,
        transactionHash: receipt.transactionHash,
      })

      toast({
        title: "Payment successful",
        description: "Your order has been processed.",
      })

      return receipt.transactionHash
    } catch (error) {
      console.error('Payment error:', error)
      toast({
        title: "Payment failed",
        description: error instanceof Error ? error.message : "Please try again",
        variant: "destructive",
      })
      throw error
    } finally {
      setIsProcessing(false)
    }
  }, [toast])

  const getOrderHistory = useCallback(async () => {
    try {
      // Get user data from localStorage
      const authUser = localStorage.getItem('authUser')
      if (!authUser) {
        throw new Error('User not authenticated')
      }
      const { id: userId } = JSON.parse(authUser)

      // Get orders from database
      const orders = await DBService.getUserOrders(userId)
      return orders
    } catch (error) {
      console.error('Get orders error:', error)
      toast({
        title: "Failed to get orders",
        description: error instanceof Error ? error.message : "Please try again",
        variant: "destructive",
      })
      throw error
    }
  }, [toast])

  return {
    isProcessing,
    processPayment,
    getOrderHistory,
  }
}
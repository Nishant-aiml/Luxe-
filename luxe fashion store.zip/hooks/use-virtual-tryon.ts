import { useState, useCallback } from "react"
import { ARService } from "@/lib/services/ar-service"
import { useToast } from "@/components/ui/use-toast"

export function useVirtualTryOn() {
  const [isProcessing, setIsProcessing] = useState(false)
  const [result, setResult] = useState<string | null>(null)
  const { toast } = useToast()

  const processImage = useCallback(async (userImage: string, productImage: string) => {
    setIsProcessing(true)
    try {
      await ARService.initializeAR()
      const processedImage = await ARService.processVirtualTryOn(userImage, productImage)
      setResult(processedImage)
      toast({
        title: "Virtual Try-On Complete",
        description: "Your virtual fitting has been generated!",
      })
    } catch (error) {
      toast({
        title: "Processing Error",
        description: "Failed to generate virtual try-on. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }, [toast])

  return {
    isProcessing,
    result,
    processImage,
  }
}
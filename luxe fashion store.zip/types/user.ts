export type Gender = 'male' | 'female'

export interface UserMeasurements {
  height: number
  shoulders: number
  chest: number
  waist: number
  hips: number
}

export interface StylePreferences {
  colors: string[]
  patterns: string[]
  fits: string[]
}

export interface UserProfile {
  id: string
  gender: Gender
  measurements: UserMeasurements
  stylePreferences: StylePreferences
}